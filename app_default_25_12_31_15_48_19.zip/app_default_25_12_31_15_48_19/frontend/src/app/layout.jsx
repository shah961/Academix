import './globals.css';
import { AuthProvider } from '@/context/AuthContext';
import ChatWidget from '@/components/ChatWidget';

export const metadata = {
  title: 'AI LMS - Learn Smarter',
  description: 'A modern Learning Management System with AI support',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <div className="min-h-screen bg-gray-50">
            {children}
            <ChatWidget />
          </div>
        </AuthProvider>
      </body>
    </html>
  );
}
