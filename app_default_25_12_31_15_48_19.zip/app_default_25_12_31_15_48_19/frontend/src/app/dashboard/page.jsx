"use client";
import { useAuth } from '@/context/AuthContext';
import { useEffect, useState } from 'react';
import { Book, GraduationCap, Users, LayoutDashboard, PlusCircle } from 'lucide-react';

export default function Dashboard() {
  const { user, loading } = useAuth();
  const [stats, setStats] = useState(null);

  useEffect(() => {
    if (user?.role === 'ADMIN') {
      fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'}/api/admin/stats`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
      .then(res => res.json())
      .then(data => setStats(data));
    }
  }, [user]);

  if (loading) return <div className="p-10 text-center">Loading dashboard...</div>;
  if (!user) return <div className="p-10 text-center">Please login to access this page.</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name}!</h1>
        <p className="text-gray-600">Role: <span className="font-semibold text-indigo-600">{user.role}</span></p>
      </header>

      {user.role === 'ADMIN' && stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatCard icon={<Users />} label="Total Users" value={stats.userCount} color="bg-blue-500" />
          <StatCard icon={<Book />} label="Total Courses" value={stats.courseCount} color="bg-green-500" />
          <StatCard icon={<GraduationCap />} label="Enrollments" value={stats.enrollmentCount} color="bg-purple-500" />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <LayoutDashboard className="text-indigo-600" /> Quick Actions
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {user.role === 'STUDENT' && (
              <ActionLink href="/courses" label="Browse Courses" />
            )}
            {(user.role === 'INSTRUCTOR' || user.role === 'ADMIN') && (
              <ActionLink href="/dashboard/courses/create" label="Create Course" icon={<PlusCircle size={18} />} />
            )}
            <ActionLink href="/profile" label="Update Profile" />
          </div>
        </section>

        <section className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold mb-4">Upcoming Tasks</h2>
          <p className="text-gray-500 italic">No tasks due today. Use the AI chat if you need help getting started!</p>
        </section>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4">
      <div className={`${color} p-3 rounded-lg text-white`}>{icon}</div>
      <div>
        <p className="text-sm text-gray-500 uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-bold">{value}</p>
      </div>
    </div>
  );
}

function ActionLink({ href, label, icon }) {
  return (
    <a href={href} className="flex items-center justify-center gap-2 p-4 border border-gray-200 rounded-lg hover:border-indigo-600 hover:text-indigo-600 transition-all font-medium">
      {icon} {label}
    </a>
  );
}
