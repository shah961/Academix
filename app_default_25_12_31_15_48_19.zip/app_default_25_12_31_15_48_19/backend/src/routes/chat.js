const express = require('express');
const router = express.Router();
const OpenAI = require('openai');
const { authenticateToken } = require('../middleware/auth');
const Course = require('../models/Course');
const Enrollment = require('../models/Enrollment');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

router.post('/query', authenticateToken, async (req, res) => {
  try {
    const { message } = req.body;
    const userId = req.user.id;
    const role = req.user.role;

    // Fetch context for AI
    const enrollments = await Enrollment.find({ student: userId }).populate('course');
    const enrolledTitles = enrollments.map(e => e.course.title).join(', ');

    const systemPrompt = `
      You are the LMS AI Support Assistant. 
      Current User Role: ${role}
      Enrolled Courses: ${enrolledTitles || 'None'}
      
      Instructions:
      1. If the user is a STUDENT, help them with course navigation, quiz questions, and progress.
      2. If the user is an INSTRUCTOR, help them with course creation steps and management.
      3. If the user is an ADMIN, provide info on system stats and user management.
      4. If they ask about platform features:
         - Enroll: Go to /courses
         - Quiz: Located at the end of modules
         - Password: Change in /profile
      5. Be professional, concise, and helpful.
    `;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      max_tokens: 300
    });

    res.json({ reply: completion.choices[0].message.content });
  } catch (error) {
    console.error('AI Error:', error);
    res.status(500).json({ 
      reply: "I'm having trouble connecting to my brain right now. Please try again later or contact support@lms.com" 
    });
  }
});

module.exports = router;
