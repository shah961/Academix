const mongoose = require('mongoose');

const lessonSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: String,
  videoUrl: String,
  order: Number
});

const quizSchema = new mongoose.Schema({
  question: String,
  options: [String],
  correctAnswer: Number // Index of option
});

const moduleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  order: Number,
  lessons: [lessonSchema],
  quizzes: [quizSchema]
});

const courseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  thumbnail: String,
  category: String,
  price: { type: Number, default: 0 },
  instructor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  status: { type: String, enum: ['PENDING', 'APPROVED', 'REJECTED'], default: 'PENDING' },
  modules: [moduleSchema],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Course', courseSchema);
