require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const User = require('./models/User');
const Course = require('./models/Course');
const Enrollment = require('./models/Enrollment');
const { authenticateToken, authorizeRoles } = require('./middleware/auth');
const chatRoutes = require('./routes/chat');

const app = express();
app.use(cors());
app.use(express.json());

// Database Connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('DB Connection Error:', err));

// --- Auth Routes ---
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hashedPassword, role });
    await user.save();
    res.status(201).json({ message: 'User created' });
  } catch (err) {
    res.status(400).json({ message: 'Registration failed', error: err.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
  const token = jwt.sign({ id: user._id, role: user.role, name: user.name }, process.env.JWT_SECRET);
  res.json({ token, user: { id: user._id, name: user.name, role: user.role } });
});

// --- Course Routes ---
app.get('/api/courses', async (req, res) => {
  const courses = await Course.find({ status: 'APPROVED' }).populate('instructor', 'name');
  res.json(courses);
});

app.post('/api/courses', authenticateToken, authorizeRoles('INSTRUCTOR', 'ADMIN'), async (req, res) => {
  const course = new Course({ ...req.body, instructor: req.user.id });
  await course.save();
  res.status(201).json(course);
});

// --- Enrollment & Progress ---
app.post('/api/courses/:id/enroll', authenticateToken, async (req, res) => {
  const existing = await Enrollment.findOne({ student: req.user.id, course: req.params.id });
  if (existing) return res.status(400).json({ message: 'Already enrolled' });
  
  const enrollment = new Enrollment({ student: req.user.id, course: req.params.id });
  await enrollment.save();
  res.status(201).json(enrollment);
});

// --- Chat Routes ---
app.use('/api/chatbot', chatRoutes);

// --- Admin Analytics ---
app.get('/api/admin/stats', authenticateToken, authorizeRoles('ADMIN'), async (req, res) => {
  const userCount = await User.countDocuments();
  const courseCount = await Course.countDocuments();
  const enrollmentCount = await Enrollment.countDocuments();
  res.json({ userCount, courseCount, enrollmentCount });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
