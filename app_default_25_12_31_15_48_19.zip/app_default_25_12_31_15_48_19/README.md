# AI Integrated Learning Management System (LMS)

A production-ready full-stack LMS featuring course management, student progress tracking, and a context-aware AI chatbot assistant.

## Features

- **Multi-Role Authentication**: Secure JWT-based login for Admin, Instructor, and Student roles.
- **AI Support Chatbot**: Persistent floating widget using OpenAI GPT, context-aware of the user's role and enrollments.
- **Course Management**: Complete CRUD for categories, courses, modules, and lessons.
- **Student Dashboard**: Browse courses, track progress, and view analytics.
- **Instructor Panel**: Course creation workflow and analytics.
- **Admin Panel**: Global statistics and system management.

## Tech Stack

- **Frontend**: Next.js 14, Tailwind CSS, Framer Motion
- **Backend**: Node.js, Express, Mongoose (MongoDB)
- **AI**: OpenAI API
- **Auth**: JWT & Bcrypt

## Prerequisites

- Node.js v18+
- MongoDB instance (local or Atlas)
- OpenAI API Key

## Installation

### 1. Backend Setup
1. Navigate to the backend folder:
    `cd backend`
2. Install dependencies:
    `npm install`
3. Create a `.env` file from the example:
    `cp .env.example .env`
4. Fill in your `MONGODB_URI`, `JWT_SECRET`, and `OPENAI_API_KEY`.
5. Start the server:
    `npm run dev`

### 2. Frontend Setup
1. Navigate to the frontend folder:
    `cd frontend`
2. Install dependencies:
    `npm install`
3. Create a `.env.local` file:
    `NEXT_PUBLIC_API_URL=http://localhost:5000`
4. Start the development server:
    `npm run dev`

## API Endpoints

- **POST /api/auth/register**: Register new user
- **POST /api/auth/login**: Login and receive JWT
- **GET /api/courses**: List approved courses
- **POST /api/chatbot/query**: Interact with AI assistant (Requires Auth)
- **GET /api/admin/stats**: Admin dashboard data (Requires Admin)

## Deployment

### Backend (Render/Railway)
- Connect your GitHub repository.
- Set environment variables.
- Start command: `npm start`.

### Frontend (Vercel)
- Set `NEXT_PUBLIC_API_URL` to your deployed backend URL.
- Vercel will automatically detect Next.js.

## Common Issues
- **CORS Error**: Ensure the frontend URL is allowed in the backend `cors()` configuration.
- **AI Timeout**: OpenAI API might take a few seconds; ensure your frontend loading states are handled.
